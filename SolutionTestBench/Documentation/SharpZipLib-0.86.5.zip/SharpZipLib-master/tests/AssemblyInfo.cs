using System.Reflection;
using System.Runtime.CompilerServices;

// Information about this assembly is defined by the following
// attributes.
//
// change them to the information which is associated with the assembly
// you compile.

[assembly: AssemblyTitle("SharpZipTests")]
[assembly: AssemblyDescription("Nunit test suite for #Zip library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ICSharpCode.net")]
[assembly: AssemblyProduct("#ZipLibrary")]
[assembly: AssemblyCopyright("Copyright 2001-2007 Mike Krueger, John Reilly")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// The assembly version has following format :
//
// Major.Minor.Build.Revision
//
// You can specify all values by your own or you can build default build and revision
// numbers with the '*' character (the default):

[assembly: AssemblyVersion("0.85.5.407")]
[assembly: AssemblyInformationalVersionAttribute("0.85.5")]

// The following attributes specify the key for the sign of your assembly. See the
// .NET Framework documentation for more information about signing.
// This is not required, if you don't want signing let these attributes like they're.
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
